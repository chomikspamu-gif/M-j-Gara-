#!/usr/bin/env bash
# Uruchamiany po „npx cap add android”: numer wersji, stały klucz podpisu, ikona, uprawnienia i wtyczka zapisu.
# Stały klucz jest ważny: dzięki niemu każda nowa wersja instaluje się NA istniejącą aplikację i dane zostają.
set -euo pipefail
G="android/app/build.gradle"
[ -f "$G" ] || { echo "Brak $G"; exit 1; }
# Bez stałego klucza podpisu Android widzi każdą kompilację jako "inną aplikację" i nie zainstaluje jej na wierzch.
[ -f keystore/mojgaraz.keystore ] || { echo "BŁĄD: brak keystore/mojgaraz.keystore: wgraj cały folder keystore do repozytorium"; exit 1; }
RUN="${GITHUB_RUN_NUMBER:-1}"
# versionCode = minuty od 1970 r. (ok. 30 mln, limit Androida to 2,1 mld), a NIE numer uruchomienia GitHuba.
# Dzięki temu każda nowa kompilacja ma wyższy numer niż poprzednia, także gdy repozytorium założysz od nowa
# i numer uruchomienia znów zacznie się od 1. Niższy numer = Android odmawia instalacji "na wierzch" (downgrade)
# i zostaje tylko odinstalowanie. To była główna przyczyna konieczności kasowania starej aplikacji.
VCODE="$(( $(date +%s) / 60 ))"
sed -i -E "s/versionCode [0-9]+/versionCode ${VCODE}/" "$G"
sed -i -E "s/versionName \"[^\"]*\"/versionName \"1.${RUN}\"/" "$G"
grep -E "versionCode|versionName" "$G" | head -2

# --- Ikona aplikacji i ikona powiadomienia (resources/android-res nadpisują domyślne zasoby Capacitora).
RES="android/app/src/main/res"
if [ -d resources/android-res ]; then
  rm -f "$RES"/mipmap-*/ic_launcher*.png "$RES"/mipmap-anydpi-v26/ic_launcher*.xml
  cp -r resources/android-res/. "$RES/"
  echo "Ikony: skopiowano resources/android-res"
else
  echo "UWAGA: brak resources/android-res, zostają domyślne ikony"
fi

# --- Manifest: zapis w Dokumentach (Android 10) i powiadomienia (Android 13+).
MF="android/app/src/main/AndroidManifest.xml"
if [ -f "$MF" ]; then
  if ! grep -q requestLegacyExternalStorage "$MF"; then
    sed -i 's/<application/<application android:requestLegacyExternalStorage="true"/' "$MF"
    echo "Manifest: requestLegacyExternalStorage"
  fi
  if ! grep -q 'android.permission.USE_EXACT_ALARM' "$MF"; then
    sed -i 's#</manifest>#    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />\n    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" android:maxSdkVersion="32" />\n</manifest>#' "$MF"
    echo "Manifest: dokładne alarmy (przypomnienia o wybranej godzinie)"
  fi
  if ! grep -q 'android.permission.WRITE_CALENDAR' "$MF"; then
    sed -i 's#</manifest>#    <uses-permission android:name="android.permission.READ_CALENDAR" />\n    <uses-permission android:name="android.permission.WRITE_CALENDAR" />\n</manifest>#' "$MF"
    echo "Manifest: kalendarz telefonu (kalendarz MójGaraż)"
  fi
  if ! grep -q 'android.permission.POST_NOTIFICATIONS' "$MF"; then
    sed -i 's#</manifest>#    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n</manifest>#' "$MF"
    echo "Manifest: POST_NOTIFICATIONS"
  fi
fi

# --- Pasek stanu w kolorze aplikacji (granat), żeby nagłówek nie kłócił się z domyślnym fioletowym paskiem Androida.
STY="android/app/src/main/res/values/styles.xml"
if [ -f "$STY" ] && ! grep -q 'android:statusBarColor' "$STY"; then
  sed -i 's#<item name="windowNoTitle">true</item>#<item name="windowNoTitle">true</item>\n        <item name="android:statusBarColor">\#0B2A5B</item>\n        <item name="android:navigationBarColor">\#0B2A5B</item>#' "$STY"
  echo "Styl: kolor paska stanu"
fi

# --- Zapis do Dokumenty/MójGaraż przez MediaStore (wtyczka SfSave). Gdyby się nie skompilowała, workflow buduje jeszcze raz bez niej.
JAVA_DIR="android/app/src/main/java/pl/mojgaraz/app"
if [ -f native/SfSavePlugin.java ] && [ -d "$JAVA_DIR" ]; then
  cp native/SfSavePlugin.java "$JAVA_DIR/SfSavePlugin.java"
  CAL_REG=""
  if [ -f native/SfCalPlugin.java ]; then
    cp native/SfCalPlugin.java "$JAVA_DIR/SfCalPlugin.java"
    CAL_REG="        registerPlugin(SfCalPlugin.class);"
    echo "Wtyczka SfCal (kalendarz telefonu): zainstalowana"
  fi
  cat > "$JAVA_DIR/MainActivity.java" <<MAINACT
package pl.mojgaraz.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(SfSavePlugin.class);
$CAL_REG
        super.onCreate(savedInstanceState);
    }
}
MAINACT
  echo "Wtyczka SfSave: zainstalowana"
else
  echo "UWAGA: brak native/SfSavePlugin.java albo katalogu $JAVA_DIR: zapis tylko przez Filesystem"
fi

cat >> "$G" <<'GRADLE'

android {
    signingConfigs {
        debug {
            storeFile file('../../keystore/mojgaraz.keystore')
            storePassword 'android'
            keyAlias 'mojgaraz'
            keyPassword 'android'
        }
    }
}
GRADLE
echo "Patched $G (versionCode ${VCODE}, build ${RUN})"
