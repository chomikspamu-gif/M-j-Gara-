#!/usr/bin/env bash
# Awaryjnie: usuwa tylko wtyczkę kalendarza (SfCal), gdyby nie przeszła kompilacja. Zapis plików (SfSave) zostaje.
set -euo pipefail
JAVA_DIR="android/app/src/main/java/pl/mojgaraz/app"
rm -f "$JAVA_DIR/SfCalPlugin.java"
cat > "$JAVA_DIR/MainActivity.java" <<'MAINACT'
package pl.mojgaraz.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(SfSavePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
MAINACT
echo "SfCal usunięta (build awaryjny, kalendarz telefonu niedostępny)"
