/* MójGaraż: mostek Android (Capacitor). Działa tylko w aplikacji natywnej (w zwykłej przeglądarce nic nie robi).
   Jest ładowany przed aplikacją, więc działa też z wersją HTML wczytaną z pliku.

   1) ZAPIS PLIKÓW: „pobrania” (<a download> z blobem) w WebView nic nie zapisują. Kopie .json (w tym automatyczny zapis po każdej zmianie)
      i raporty .pdf zapisują się po cichu do Dokumenty/MójGaraż (MediaStore, bez uprawnień; zapasowo wtyczka Filesystem).
      Pliki do otwarcia w innej aplikacji (.ics do kalendarza) idą przez systemowe okno „Udostępnij”.
   2) POWIADOMIENIA: WebView nie ma Notification API ani Service Workera, więc aplikacja dostaje podstawki (Notification, navigator.serviceWorker
      i rejestracja z showNotification/getNotifications) oparte na wtyczce LocalNotifications. Dzięki temu cała logika terminów z HTML działa bez zmian,
      a powiadomienia są prawdziwymi powiadomieniami Androida (pasek stanu + kropka przy ikonie). Dodatkowo most planuje powiadomienia
      na przyszłe daty terminów (godz. 9:00), więc przychodzą także wtedy, gdy aplikacja jest zamknięta.
   3) AKTUALIZACJA Z PLIKU HTML: w Ustawieniach pojawia się sekcja „Aplikacja Android” z przyciskiem „Wczytaj nowy plik HTML”.
   4) ODTWORZENIE DANYCH: gdy aplikacja jest pusta (nowa instalacja / „Wyczyść dane”), a w Dokumenty/MójGaraż leży kopia, most proponuje jej wczytanie.
   Zależności od kodu aplikacji (nowe pliki HTML muszą je zachować): funkcja download(), ID elementów #toast/#toastMsg/#setBody/#imp/#autoExpInfo/#instInfo,
   zmienne APP_VER i db, funkcje allItems, syncNotif, notifOn, renderSettings, klucze localStorage serwisDB i mgNotif. */
(function () {
  'use strict';
  var C = window.Capacitor;
  if (!C || typeof C.isNativePlatform !== 'function' || !C.isNativePlatform()) return;
  if (window.__mgBridge) return;   // loader nowej wersji z pliku uruchamia skrypty od nowa: druga kopia mostu nie jest potrzebna
  window.__mgBridge = true;
  var P = C.Plugins || {};
  var FS = P.Filesystem;
  var SH = P.Share;
  var LN = P.LocalNotifications;
  var SF = P.SfSave || null;   // własna wtyczka (MediaStore): zapis do Dokumenty/MójGaraż bez uprawnień
  try { if (!SF && typeof C.registerPlugin === 'function') SF = C.registerPlugin('SfSave'); } catch (e) {}
  var DIR = 'MójGaraż';
  var ROOT = 'DOCUMENTS';
  var origClick = HTMLAnchorElement.prototype.click;
  var t0 = Date.now();

  function ls(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); return true; } catch (e) { return false; } }
  function lsDel(k) { try { localStorage.removeItem(k); } catch (e) {} }
  function toBase64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(',')[1] || ''); };
      r.onerror = function () { rej(r.error); };
      r.readAsDataURL(blob);
    });
  }
  function fromBase64Text(b64) {
    var bin = atob(b64), n = bin.length, u8 = new Uint8Array(n);
    for (var i = 0; i < n; i++) u8[i] = bin.charCodeAt(i);
    return new TextDecoder('utf-8').decode(u8);
  }
  function safeName(name) { return String(name || 'plik').replace(/[\\/:*?"<>|]+/g, '_'); }
  function errText(e) { return String((e && (e.message || e.code)) || e || '?'); }
  function cmpVer(a, b) {
    var x = String(a).split('.'), y = String(b).split('.');
    for (var i = 0; i < Math.max(x.length, y.length); i++) {
      var p = parseInt(x[i], 10) || 0, q = parseInt(y[i], 10) || 0;
      if (p !== q) return p > q ? 1 : -1;
    }
    return 0;
  }
  /* Czeka, aż aplikacja się narysuje (po wczytaniu z pliku DOM jest podmieniany, więc czekam też na jej funkcje). */
  function whenAppReady(fn) {
    var n = 0, iv = setInterval(function () {
      n++;
      if (document.readyState === 'complete' && document.getElementById('setBody') && typeof window.renderSettings === 'function') {
        clearInterval(iv);
        try { fn(); } catch (e) {}
      } else if (n > 100) clearInterval(iv);
    }, 300);
  }

  /* ---------- 1. zapis plików ---------- */
  var permOk = null, failed = false;
  async function ensurePerm() {
    if (!FS) return false;
    if (permOk !== null) return permOk;
    try {
      var s = await FS.checkPermissions();
      if (s && s.publicStorage && s.publicStorage !== 'granted') s = await FS.requestPermissions();
      permOk = !(s && s.publicStorage) || s.publicStorage === 'granted';
    } catch (e) { permOk = true; }   // nowsze Androidy: uprawnienie niepotrzebne, o wyniku zdecyduje sam zapis
    return permOk;
  }
  async function fileSize(path) {
    try { return (await FS.stat({ path: path, directory: ROOT })).size || 0; } catch (e) { return 0; }
  }
  function mimeOf(name) {
    return /\.json$/i.test(name) ? 'application/json' : /\.pdf$/i.test(name) ? 'application/pdf' : /\.ics$/i.test(name) ? 'text/calendar' : 'application/octet-stream';
  }
  /* Sposób 1: MediaStore (wtyczka SfSave), w kawałkach po ok. 1,5 MB. Sposób 2 (zapas): wtyczka Filesystem. */
  async function saveMediaStore(name, blob) {
    var CH = 3 * 512 * 1024, n = Math.max(1, Math.ceil(blob.size / CH));
    for (var i = 0; i < n; i++) {
      var part = blob.slice(i * CH, Math.min(blob.size, (i + 1) * CH));
      await SF.save({ name: safeName(name), data: await toBase64(part), folder: DIR, mime: mimeOf(name), append: i > 0, total: blob.size });
    }
  }
  async function saveFilesystem(name, blob) {
    if (!(await ensurePerm())) throw new Error('brak zgody aplikacji na pliki (Ustawienia Androida → Aplikacje → MójGaraż → Uprawnienia)');
    var b64 = await toBase64(blob);
    var path = DIR + '/' + safeName(name);
    var oldSize = await fileSize(path);
    if (oldSize > 0) {
      try { await FS.deleteFile({ path: path + '.bak', directory: ROOT }); } catch (e) {}
      try { await FS.copy({ from: path, to: path + '.bak', directory: ROOT, toDirectory: ROOT }); } catch (e) {}
      if (oldSize > 20000 && blob.size < oldSize / 3) {   // nowy zapis wyraźnie mniejszy (np. po wyczyszczeniu danych): zachowaj starą wersję osobno
        var keep = DIR + '/przed-nadpisaniem_' + safeName(name);
        try { await FS.deleteFile({ path: keep, directory: ROOT }); } catch (e) {}
        try { await FS.copy({ from: path, to: keep, directory: ROOT, toDirectory: ROOT }); } catch (e) {}
      }
    }
    await FS.writeFile({ path: path, data: b64, directory: ROOT, recursive: true });
  }
  async function silentSave(name, blob) {
    var e1 = null;
    if (SF) {
      try { await saveMediaStore(name, blob); return; } catch (e) { e1 = e; }
    }
    try { await saveFilesystem(name, blob); }
    catch (e2) {
      throw new Error((e1 ? 'MediaStore: ' + errText(e1) + '; ' : '') + errText(e2) + ' [' + Math.round(blob.size / 1024) + ' KB]');
    }
  }
  function reportSaveError(e) {
    if (failed) return;   // jedno okienko na uruchomienie, nie męczę użytkownika
    failed = true;
    try { alert('Zapis do folderu Dokumenty/' + DIR + ' się nie udał: ' + errText(e) + '\nDane są nadal w aplikacji. Zrób kopię ręcznie (Ustawienia → Kopia zapasowa → Zapisz plik) i sprawdź uprawnienia aplikacji do plików.'); } catch (x) {}
  }
  /* Kolejka „ostatni wygrywa” dla każdego pliku: kilka szybkich zmian pod rząd nie robi kilku równoległych zapisów tego samego pliku. */
  var latest = {}, running = {};
  async function pump(name) {
    running[name] = true;
    try {
      while (latest[name]) {
        var b = latest[name]; latest[name] = null;
        await silentSave(name, b);
      }
    } catch (e) { reportSaveError(e); }
    running[name] = false;
  }
  function queueSave(url, name) {
    fetch(url).then(function (r) { return r.blob(); }).then(function (b) {
      latest[name] = b;
      if (!running[name]) pump(name);
    }).catch(reportSaveError);
  }
  async function saveAndShare(url, name) {
    try {
      var blob = await (await fetch(url)).blob();
      var safe = safeName(name);
      var w = await FS.writeFile({ path: safe, data: await toBase64(blob), directory: 'CACHE' });
      await SH.share({ title: safe, url: w.uri, dialogTitle: 'Otwórz lub zapisz plik' });
    } catch (e) {
      var msg = errText(e);
      if (!/cancel|dismiss/i.test(msg)) alert('Nie udało się otworzyć pliku: ' + msg);
    }
  }
  /* Zapisem są kopie .json i raporty .pdf: idą po cichu do Dokumenty/MójGaraż. Pozostałe pliki (np. .ics do kalendarza) otwiera okno „Udostępnij”. */
  function isSaveName(n) { return /\.(json|pdf)$/i.test(String(n || '')); }
  HTMLAnchorElement.prototype.click = function () {
    try {
      if (this.download && /^(blob:|data:)/.test(this.href)) {
        if ((FS || SF) && isSaveName(this.download)) { queueSave(this.href, this.download); return; }
        if (FS && SH) { saveAndShare(this.href, this.download); return; }
      }
    } catch (e) {}
    return origClick.apply(this, arguments);
  };
  /* WebView nie obsługuje okna wyboru pliku (showSaveFilePicker): udaję, że go nie ma. */
  try {
    try { delete window.showSaveFilePicker; } catch (e) {}
    if (typeof window.showSaveFilePicker === 'function') Object.defineProperty(window, 'showSaveFilePicker', { value: undefined, configurable: true, writable: true });
  } catch (e) {}
  /* navigator.share / canShare (WebView ich nie ma): okno „Udostępnij” na wtyczce Share. Pliki-zapisy (.json/.pdf) nie idą tą drogą. */
  try {
    if (SH && typeof navigator.share !== 'function') {
      navigator.canShare = function (d) {
        if (!d) return true;
        if (d.files && d.files.length) {
          for (var i = 0; i < d.files.length; i++) if (isSaveName(d.files[i].name)) return false;
          return !!FS;
        }
        return !!(d.text || d.url || d.title);
      };
      navigator.share = async function (d) {
        d = d || {};
        try {
          if (d.files && d.files.length) {
            var f = d.files[0], safe = safeName(f.name || d.title || 'plik');
            var w = await FS.writeFile({ path: safe, data: await toBase64(f), directory: 'CACHE' });
            await SH.share({ title: d.title || safe, url: w.uri, dialogTitle: 'Otwórz lub zapisz plik' });
          } else {
            await SH.share({ title: d.title, text: d.text, url: d.url, dialogTitle: 'Udostępnij' });
          }
        } catch (e) {
          if (/cancel|dismiss/i.test(errText(e))) throw new DOMException('Share canceled', 'AbortError');
          throw e;
        }
      };
    }
  } catch (e) {}

  /* ---------- teksty aplikacji, które w wersji natywnej byłyby nieprawdziwe („Pobrane”, „Chrome”) ---------- */
  var HIDE_TOAST = /^(Zapisano kopię ✓ \(folder Pobrane\)|Pobrano plik z danymi|Otwórz pobrany plik|Pobrano plik — otwórz go)/;
  function fixToast() {
    var t = document.getElementById('toast'), m = document.getElementById('toastMsg');
    if (!t || !m) return;
    var x = m.textContent || '';
    if (HIDE_TOAST.test(x)) { t.style.display = 'none'; return; }   // zapis kopii/otwarcie pliku dzieje się po cichu lub w oknie systemowym
    if (/^Zapisano PDF w folderze Pobrane/.test(x)) m.textContent = x.replace('w folderze Pobrane', 'w Dokumenty/' + DIR);
  }
  function replaceText(root, from, to) {
    if (!root || (root.textContent || '').indexOf(from) < 0) return;
    var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), n;
    while ((n = w.nextNode())) { if (n.nodeValue.indexOf(from) > -1) n.nodeValue = n.nodeValue.replace(from, to); }
  }
  function fixTexts() {
    var a = document.getElementById('autoExpInfo');
    if (a && a.textContent.indexOf('do folderu Pobrane') > -1) {
      replaceText(a, 'do folderu Pobrane. Chrome może zapytać o zgodę na pobieranie wielu plików.', 'do folderu Dokumenty/' + DIR + ' (po cichu, bez okien; plik zostaje po „Wyczyść dane”).');
      replaceText(a, 'do folderu Pobrane', 'do folderu Dokumenty/' + DIR);
    }
    var i = document.getElementById('instInfo');
    if (i && i.textContent.indexOf('Otwieraj MójGaraż') > -1) i.textContent = 'Aplikacja na Androida. Kopie i raporty zapisują się po cichu w Dokumenty/' + DIR + '.';
    var h = document.getElementById('installHost'); if (h) h.style.display = 'none';
    var fr = document.querySelector('[data-act="forceReload"]'); if (fr) fr.style.display = 'none';   // odświeżanie pamięci PWA nie dotyczy aplikacji
    injectUpdateBox();
  }
  try {
    var fixT = null;
    new MutationObserver(function () {
      try { fixToast(); } catch (e) {}
      if (fixT) return;
      fixT = setTimeout(function () { fixT = null; try { fixTexts(); } catch (e) {} }, 80);
    }).observe(document, { childList: true, subtree: true, characterData: true });
  } catch (e) {}

  /* ---------- 2. powiadomienia (LocalNotifications) ---------- */
  var CH_ID = 'mg_terminy', SMALL_ICON = 'ic_stat_mojgaraz', SCHED_BASE = 7000, SCHED_END = 8000;
  var perm = 'default';
  function setPerm(s) { perm = s === 'granted' ? 'granted' : s === 'denied' ? 'denied' : 'default'; }
  function idFor(tag) {   // ten sam tag = to samo ID = nowe powiadomienie zastępuje stare
    var h = 0, s = String(tag || 'mg');
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
    return 6000 + (Math.abs(h) % 900);
  }
  var chanDone = false;
  async function ensureChannel() {
    if (chanDone || !LN) return;
    try {
      await LN.createChannel({ id: CH_ID, name: 'Terminy serwisowe', description: 'Zbliżające się terminy: serwis, przegląd, OC/AC',
        importance: 4, visibility: 1, vibration: true, lights: true, lightColor: '#1F6FEB' });
    } catch (e) {}
    chanDone = true;
  }
  if (LN) {
    var fakeReg = {
      scope: './',
      showNotification: function (title, o) {
        o = o || {};
        var tag = o.tag || 'mg', body = String(o.body || ''), first = body.split('\n')[0] || '';
        return ensureChannel().then(function () {
          return LN.schedule({ notifications: [{
            id: idFor(tag), title: String(title || 'MójGaraż'), body: first, largeBody: body, summaryText: 'MójGaraż',
            channelId: CH_ID, smallIcon: SMALL_ICON, iconColor: '#1F6FEB',
            extra: { tag: tag, url: (o.data && o.data.url) || './' }
          }] });
        });
      },
      getNotifications: function (f) {
        var want = f && f.tag ? idFor(f.tag) : null;
        return LN.getDeliveredNotifications().then(function (r) {
          return ((r && r.notifications) || []).filter(function (n) { return want === null || Number(n.id) === want; }).map(function (n) {
            return { tag: f && f.tag, title: n.title, body: n.body, close: function () { try { LN.removeDeliveredNotifications({ notifications: [{ id: n.id }] }); } catch (e) {} } };
          });
        }).catch(function () { return []; });
      },
      unregister: function () { return Promise.resolve(true); },
      update: function () { return Promise.resolve(); }
    };
    function NotifShim() {}
    Object.defineProperty(NotifShim, 'permission', { get: function () { return perm; } });
    NotifShim.requestPermission = function (cb) {
      return LN.requestPermissions().then(function (r) { setPerm(r && r.display); if (cb) cb(perm); return perm; }).catch(function () { return perm; });
    };
    try { Object.defineProperty(window, 'Notification', { value: NotifShim, configurable: true, writable: true }); } catch (e) { try { window.Notification = NotifShim; } catch (x) {} }
    try {
      var sw = navigator.serviceWorker;
      if (sw) {
        try { Object.defineProperty(sw, 'register', { value: function () { return Promise.resolve(fakeReg); }, configurable: true, writable: true }); } catch (e) {}
        try { Object.defineProperty(sw, 'ready', { get: function () { return Promise.resolve(fakeReg); }, configurable: true }); } catch (e) {}
      } else {
        Object.defineProperty(navigator, 'serviceWorker', { configurable: true, value: {
          register: function () { return Promise.resolve(fakeReg); }, ready: Promise.resolve(fakeReg), controller: null,
          getRegistration: function () { return Promise.resolve(fakeReg); }, addEventListener: function () {}, removeEventListener: function () {}
        } });
      }
    } catch (e) {}

    /* Plan na przyszłość: powiadomienia o 9:00 w dniach wokół terminów (za 14/7/3/1 dni, w dniu terminu, po terminie 3/7/14/30 dni).
       Terminy liczone od przebiegu (km) mają datę tylko szacunkową: te pokazuje zwykłe powiadomienie przy zejściu aplikacji do tła. */
    var OFFSETS = [-14, -7, -3, -1, 0, 3, 7, 14, 30], MAX_SCHED = 60, schedBusy = false, schedAgain = false, schedT = null;
    function plDni(n) { return n === 1 ? '1 dzień' : n + ' dni'; }
    function offLabel(off) { return off < 0 ? 'za ' + plDni(-off) : off === 0 ? 'dziś' : plDni(off) + ' po terminie'; }
    function dayKey(d) { return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
    function notifEnabled() { return ls('mgNotif') === '1' && perm === 'granted'; }
    async function cancelSched() {
      try {
        var pend = await LN.getPending();
        var ids = ((pend && pend.notifications) || []).filter(function (n) { return n.id >= SCHED_BASE && n.id < SCHED_END; }).map(function (n) { return { id: n.id }; });
        if (ids.length) await LN.cancel({ notifications: ids });
      } catch (e) {}
    }
    async function scheduleUpcoming() {
      if (schedBusy) { schedAgain = true; return; }
      schedBusy = true;
      try {
        await ensureChannel();
        await cancelSched();
        if (!notifEnabled() || typeof window.allItems !== 'function') return;
        if (typeof window.mgPlan === 'function') {   // plan z aplikacji: godzina z ustawień, zapas czasu dokumentów, szacunek z przebiegu, własne przypomnienia
          var plan = window.mgPlan();
          var pn = plan.map(function (g, idx) {
            var o = { id: SCHED_BASE + idx, title: g.title, body: g.body, summaryText: 'MójGaraż', channelId: CH_ID, smallIcon: SMALL_ICON, iconColor: '#1F6FEB',
              schedule: { at: g.at, allowWhileIdle: true }, extra: { tag: 'mg-sched', url: './', date: g.date } };
            if (g.n > 1 && g.lines) o.inboxList = g.lines; else o.largeBody = g.large;   // kilka terminów: rozwijana lista, każdy w osobnym wierszu
            return o;
          });
          if (pn.length) await LN.schedule({ notifications: pn });
          return;
        }
        var items = window.allItems(), many = typeof window.activeCars === 'function' && window.activeCars().length > 1;
        var now = Date.now(), horizon = now + 150 * 86400000, days = {};
        var base = new Date(); base = new Date(base.getFullYear(), base.getMonth(), base.getDate());
        items.forEach(function (it) {
          if (typeof it.days !== 'number' || !isFinite(it.days)) return;
          OFFSETS.forEach(function (off) {
            var d = new Date(base.getFullYear(), base.getMonth(), base.getDate() + it.days + off, 9, 0, 0);
            if (d.getTime() <= now + 60000 || d.getTime() > horizon) return;
            var k = dayKey(d);
            (days[k] = days[k] || { at: d, rows: [] }).rows.push({ it: it, off: off });
          });
        });
        var list = Object.keys(days).map(function (k) { return days[k]; }).sort(function (a, b) { return a.at - b.at; }).slice(0, MAX_SCHED);
        var notes = list.map(function (g, idx) {
          var rows = g.rows.sort(function (a, b) { return Math.abs(a.off) - Math.abs(b.off); });
          var lines = rows.slice(0, 4).map(function (r) {
            var car = many && typeof window.carById === 'function' ? window.carById(r.it.car) : null;
            return (car ? car.name + ': ' : '') + r.it.title + ' — ' + offLabel(r.off);
          });
          if (rows.length > 4) lines.push('… i ' + (rows.length - 4) + ' więcej');
          var n = rows.length, term = typeof window.plTerm === 'function' ? window.plTerm(n) : (n === 1 ? 'termin' : 'terminy');
          return { id: SCHED_BASE + idx, title: n === 1 ? 'MójGaraż: ' + rows[0].it.title : 'MójGaraż: ' + n + ' ' + term,
            body: lines[0], largeBody: lines.join('\n'), summaryText: 'MójGaraż', channelId: CH_ID, smallIcon: SMALL_ICON, iconColor: '#1F6FEB',
            schedule: { at: g.at, allowWhileIdle: true }, extra: { tag: 'mg-sched', url: './' } };
        });
        if (notes.length) await LN.schedule({ notifications: notes });
      } catch (e) {
      } finally {
        schedBusy = false;
        if (schedAgain) { schedAgain = false; kickSched(2000); }
      }
    }
    function kickSched(ms) { clearTimeout(schedT); schedT = setTimeout(scheduleUpcoming, ms == null ? 4000 : ms); }
    async function clearLegacyDue() {   // dawne powiadomienie „przy zejściu do tła” (mg-due) już nie jest używane; przypomnienia push zostają na pasku, dopóki ich nie zamkniesz
      var id = idFor('mg-due');
      try { await LN.removeDeliveredNotifications({ notifications: [{ id: id }] }); } catch (e) {}
      try { await LN.cancel({ notifications: [{ id: id }] }); } catch (e) {}
    }
    /* każda zmiana bazy (serwisDB) albo przełącznika powiadomień przelicza plan */
    try {
      var origSet = Storage.prototype.setItem;
      Storage.prototype.setItem = function (k) {
        var r = origSet.apply(this, arguments);
        if (k === 'serwisDB' || k === 'mgNotif' || k === 'mgNotifHM') kickSched();
        return r;
      };
    } catch (e) {}
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) kickSched(300);
    });
    window.addEventListener('pagehide', function () { kickSched(100); });

    function afterPerm() {
      try { if (typeof window.syncNotif === 'function') window.syncNotif(); } catch (e) {}
      try { var s = document.getElementById('mSet'); if (s && s.classList.contains('show') && typeof window.renderSettings === 'function') window.renderSettings(); } catch (e) {}
      kickSched(1500);
    }
    /* Test: powiadomienie za minutę, żeby sprawdzić push przy zamkniętej aplikacji. */
    /* przycisk Wstecz: obsługa w aplikacji (okna → widok główny → „naciśnij jeszcze raz, aby wyjść”) */
    try {
      var APP = P.App; if (!APP && typeof C.registerPlugin === 'function') APP = C.registerPlugin('App');
      if (APP && typeof APP.addListener === 'function') {
        APP.addListener('backButton', function () { if (typeof window.mgBack === 'function') window.mgBack(); else history.back(); });
        window.mgExit = function () { try { APP.exitApp(); } catch (e) {} };
      }
    } catch (e) {}
    window.mgExactCheck = async function () {   // true/false/null (null = nie da się sprawdzić)
      try { if (typeof LN.checkExactNotificationSetting !== 'function') return null; var r = await LN.checkExactNotificationSetting(); return r && r.exact_alarm !== 'denied'; } catch (e) { return null; }
    };
    window.mgExactOpen = async function () { try { await LN.changeExactNotificationSetting(); } catch (e) {} };
    window.mgTestPush = async function () {
      try {
        await ensureChannel();
        await LN.schedule({ notifications: [{ id: 6990, title: 'MójGaraż: test push', body: 'Jeśli to widzisz przy zamkniętej aplikacji, przypomnienia działają.',
          channelId: CH_ID, smallIcon: SMALL_ICON, iconColor: '#1F6FEB', schedule: { at: new Date(Date.now() + 60000), allowWhileIdle: true }, extra: { tag: 'mg-test' } }] });
        return true;
      } catch (e) { return false; }
    };
    function patchNotifTexts() {
      window.syncNotif = function () {};   // żadnych powiadomień przy otwieraniu i zamykaniu aplikacji: tylko zaplanowane push
      window.notifStatusText = function () {
        if (perm === 'denied') return 'Powiadomienia są zablokowane: Ustawienia Androida → Aplikacje → MójGaraż → Powiadomienia.';
        if (typeof window.notifOn === 'function' && window.notifOn()) return 'Włączone. Przypomnienia przychodzą jako powiadomienia push o ustawionej godzinie, także gdy aplikacja jest zamknięta.';
        return 'Wyłączone.';
      };
    }
    LN.checkPermissions().then(function (r) { setPerm(r && r.display); }).catch(function () {});
    ensureChannel();
    whenAppReady(function () {
      patchNotifTexts();
      clearLegacyDue();
      try {
        LN.addListener('localNotificationActionPerformed', function (a) {   // dotknięcie powiadomienia otwiera kalendarz na dniu terminu
          var x = a && a.notification && a.notification.extra, d = x && x.date;
          if (typeof window.mgOpenCal === 'function') setTimeout(function () { window.mgOpenCal(d || undefined); }, 300);
        });
      } catch (e) {}
      (async function () {
        try {
          var r = await LN.checkPermissions(); setPerm(r && r.display);
          if (!ls('mg_notif_init')) {   // pierwsze uruchomienie: poproś o zgodę i włącz powiadomienia o terminach
            lsSet('mg_notif_init', '1');
            if (perm !== 'granted') { var q = await LN.requestPermissions(); setPerm(q && q.display); }
            if (perm === 'granted') { lsSet('mgNotif', '1'); lsDel('mgNotifSig'); }
          }
        } catch (e) {}
        afterPerm();
      })();
    });
  }

  /* ---------- 2b. kalendarz w telefonie (wtyczka SfCal): kalendarz „MójGaraż” z terminami z aplikacji ---------- */
  (function () {
    var CAL = P.SfCal || null;
    try { if (!CAL && typeof C.registerPlugin === 'function') CAL = C.registerPlugin('SfCal'); } catch (e) {}
    if (!CAL) return;
    var avail = false, calT = null, busy = false, again = false;
    function paint() {
      var b = document.getElementById('calSyncBox'), sw = document.getElementById('swCalSync');
      if (b) b.classList.toggle('hidden', !avail);
      if (sw) { sw.classList.toggle('on', ls('mgCalSync') === '1'); sw.setAttribute('aria-checked', ls('mgCalSync') === '1' ? 'true' : 'false'); }
    }
    function say(m) { try { if (typeof window.toast === 'function') window.toast(m, { ms: 6000 }); } catch (e) {} }
    async function doSync() {
      if (busy) { again = true; return null; }
      busy = true;
      try {
        var ev = (typeof window.mgCalEvents === 'function' && window.mgCalEvents()) || [];
        var r = await CAL.sync({ events: ev });
        return r && r.count;
      } finally { busy = false; if (again) { again = false; kick(2000); } }
    }
    function kick(ms) {
      if (ls('mgCalSync') !== '1') return;
      clearTimeout(calT); calT = setTimeout(function () { doSync().catch(function () {}); }, ms == null ? 3000 : ms);
    }
    window.mgPhoneCal = function () { return { avail: avail, on: ls('mgCalSync') === '1' }; };
    window.mgCalToggle = async function () {
      if (ls('mgCalSync') === '1') {
        lsSet('mgCalSync', '0'); paint();
        try { await CAL.remove(); } catch (e) {}
        say('Kalendarz „MójGaraż” usunięty z telefonu');
        return;
      }
      try {
        var n = await doSync();
        lsSet('mgCalSync', '1'); paint();
        say('Kalendarz „MójGaraż” utworzony (' + (n || 0) + ' terminów). Znajdziesz go w aplikacji Kalendarz.');
      } catch (e) {
        var m = String((e && (e.message || e.code)) || e);
        say(/DENIED/.test(m) ? 'Brak zgody na kalendarz. Zezwól: Ustawienia Androida → Aplikacje → MójGaraż → Uprawnienia → Kalendarz.' : 'Nie udało się utworzyć kalendarza: ' + m);
      }
    };
    try {
      var origSet2 = Storage.prototype.setItem;
      Storage.prototype.setItem = function (k) { var r = origSet2.apply(this, arguments); if (k === 'serwisDB' || k === 'mgNotifHM') kick(); return r; };
    } catch (e) {}
    whenAppReady(function () {
      try { var rs = window.renderSettings; if (typeof rs === 'function') window.renderSettings = function () { var r = rs.apply(this, arguments); paint(); return r; }; } catch (e) {}
      CAL.status().then(function () { avail = true; paint(); kick(6000); }).catch(function () { avail = false; paint(); });
    });
  })();

  /* ---------- 3. aktualizacja aplikacji z pliku HTML (Ustawienia → Aplikacja Android) ---------- */
  var K = 'mg_app_override', KM = 'mg_app_override_meta', KT = 'mg_app_override_try';
  function runningVer() { try { return window.APP_VER || '?'; } catch (e) { return '?'; } }
  function baseVer() { return window.__mgBase || (document.querySelector('meta[name=mg-app-ver]') || {}).content || '?'; }
  function updInfoHtml() {
    var meta = null; try { meta = JSON.parse(ls(KM) || 'null'); } catch (e) {}
    var fromFile = !!window.__mgOvr;
    var s = 'Wbudowana wersja: <b>' + baseVer() + '</b> · działa: <b>' + runningVer() + '</b>' + (fromFile ? ' (z pliku)' : '');
    if (!fromFile && meta && meta.ver) s += '<br>Wczytano plik z wersją ' + meta.ver + ': uruchomi się po ponownym otwarciu aplikacji.';
    if (window.__mgOvrFailed) s += '<br>Wczytany plik nie uruchomił się poprawnie, więc został porzucony.';
    return s;
  }
  function injectUpdateBox() {
    return;   // opcje aktualizacji z pliku usunięte z Ustawień na życzenie
    var info = document.getElementById('dataInfo');
    if (!info || document.getElementById('mgApk')) {
      var ex = document.getElementById('mgApkInfo'), h = updInfoHtml();
      if (ex && ex.innerHTML !== h) ex.innerHTML = h;   // tylko gdy się zmieniło: inaczej obserwator DOM kręciłby się w kółko
      return;
    }
    var box = document.createElement('div');
    box.id = 'mgApk';
    box.innerHTML = '<div class="subHd" style="margin-top:14px">Aktualizacja aplikacji z pliku</div>' +
      '<div class="status" id="mgApkInfo" style="margin-top:6px"></div>' +
      '<button class="btn out block" id="mgApkLoad" style="margin-top:10px">Wczytaj nowy plik HTML</button>' +
      '<button class="btn ghost block" id="mgApkReset" style="margin-top:8px">Wróć do wersji wbudowanej</button>' +
      '<small class="hint">Plik index.html z nową wersją aplikacji. Dane i ustawienia zostają. Nowa wersja z GitHuba zastąpi wczytany plik.</small>' +
      '<input type="file" id="mgApkFile" accept=".html,.htm,text/html" class="hidden" style="display:none">';
    info.parentNode.insertBefore(box, info.nextSibling);
    document.getElementById('mgApkInfo').innerHTML = updInfoHtml();
    var reset = document.getElementById('mgApkReset');
    var active = !!window.__mgOvr || !!ls(KM);
    reset.style.display = active ? '' : 'none';
    document.getElementById('mgApkLoad').addEventListener('click', function () { document.getElementById('mgApkFile').click(); });
    reset.addEventListener('click', function () {
      if (!confirm('Wrócić do wersji wbudowanej w aplikację (' + baseVer() + ')? Dane zostają.')) return;
      lsDel(K); lsDel(KM); lsDel(KT); location.reload();
    });
    document.getElementById('mgApkFile').addEventListener('change', function (e) {
      var f = e.target.files && e.target.files[0]; e.target.value = '';
      if (!f) return;
      var rd = new FileReader();
      rd.onload = function () {
        var html = String(rd.result || ''), m = html.match(/APP_VER\s*=\s*["']([^"']+)["']/);
        if (!m || html.indexOf('serwisDB') < 0 || html.indexOf('id="mSet"') < 0) { alert('To nie wygląda na plik aplikacji MójGaraż (brak wersji lub ekranu ustawień). Nic nie zmieniono.'); return; }
        var ver = m[1], cur = runningVer();
        if (cmpVer(ver, cur) <= 0 && !confirm('Wybrany plik ma wersję ' + ver + ', a działa ' + cur + '. To nie jest nowsza wersja. Wczytać mimo to?')) return;
        if (!confirm('Wczytać wersję ' + ver + ' z pliku ' + f.name + '? Aplikacja uruchomi się ponownie. Dane zostają.')) return;
        if (!lsSet(K, html)) { alert('Brak miejsca w pamięci aplikacji na nowy plik. Zrób kopię (Ustawienia → Kopia zapasowa), usuń zbędne zdjęcia albo zbuduj nowy APK na GitHubie.'); return; }
        lsSet(KM, JSON.stringify({ ver: ver, base: baseVer(), force: true, savedAt: Date.now(), size: html.length, name: f.name }));
        lsDel(KT);
        location.reload();
      };
      rd.onerror = function () { alert('Nie udało się odczytać pliku.'); };
      rd.readAsText(f);
    });
  }
  whenAppReady(function () { injectUpdateBox(); fixTexts(); });

  /* ---------- 4. odtworzenie danych, gdy aplikacja jest pusta ---------- */
  var restoreTried = false;
  function dbEmpty() {
    try { var d = JSON.parse(ls('serwisDB') || 'null'); return !d || !d.cars || !d.cars.length; } catch (e) { return true; }
  }
  function countOf(text) {
    try { var d = JSON.parse(text); return d && d.cars && d.records ? { cars: d.cars.length, recs: d.records.length } : null; } catch (e) { return null; }
  }
  async function bestBackup() {
    var r = await FS.readdir({ path: DIR, directory: ROOT });
    var list = ((r && r.files) || []).filter(function (f) { return /^(przed-nadpisaniem_)?mojgaraz_(dane|backup).*\.json$/i.test(f.name || ''); });
    list.sort(function (a, b) { return (b.mtime || 0) - (a.mtime || 0); });
    var best = null;
    for (var i = 0; i < Math.min(list.length, 6); i++) {
      try {
        var rd = await FS.readFile({ path: DIR + '/' + list[i].name, directory: ROOT });
        var text = fromBase64Text(rd.data), c = countOf(text);
        if (c && c.cars > 0 && (!best || c.recs + c.cars > best.c.recs + best.c.cars)) best = { info: list[i], text: text, c: c };
      } catch (e) {}
    }
    return best;
  }
  async function tryRestore() {
    if (restoreTried) return;
    restoreTried = true;
    try {
      if (!FS || !dbEmpty()) return;
      if (!(await ensurePerm())) return;
      var best = await bestBackup();
      if (!best) return;
      var key = best.info.name + ':' + (best.info.mtime || 0);
      if (ls('mg_restore_asked') === key) return;   // ten plik już proponowałem
      lsSet('mg_restore_asked', key);
      var inp = document.getElementById('imp');
      if (!inp) return;
      var when = best.info.mtime ? ' z ' + new Date(best.info.mtime).toLocaleString('pl-PL') : '';
      if (!confirm('W folderze Dokumenty/' + DIR + ' jest kopia Twoich danych' + when + ' (' + best.c.cars + ' aut, ' + best.c.recs + ' wpisów).\n\nWczytać ją teraz?')) return;
      var dt = new DataTransfer();
      dt.items.add(new File([best.text], best.info.name, { type: 'application/json' }));
      inp.files = dt.files;
      inp.dispatchEvent(new Event('change', { bubbles: true }));   // dalej prowadzi zwykłe okno aplikacji „Wczytać kopię?”
    } catch (e) { /* brak folderu = nic do odtworzenia */ }
  }
  whenAppReady(function () { setTimeout(tryRestore, 1200); });
})();
