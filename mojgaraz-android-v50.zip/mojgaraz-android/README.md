# MójGaraż: aplikacja na Androida

Ta sama aplikacja co w przeglądarce (`src/index.html`), opakowana w Capacitor. GitHub zbuduje z niej plik **APK**, który zainstalujesz na telefonie.

## Jak zbudować na GitHubie

1. Załóż na github.com **prywatne** repozytorium (np. `mojgaraz`). Ma być prywatne, bo w środku jest klucz podpisu aplikacji.
2. Wgraj do niego całą zawartość tego zipa, razem z ukrytym folderem `.github`.
   - Przez stronę: „Add file → Upload files” i przeciągnij pliki po rozpakowaniu. Jeśli `.github` się nie wgra, wybierz „Add file → Create new file”, wpisz nazwę `.github/workflows/android.yml` i wklej zawartość tego pliku z zipa.
3. Wejdź w **Actions → Build Android APK**. Build startuje sam po wgraniu plików (albo „Run workflow”). Trwa kilka minut.
4. Gdy zrobi się zielony, plik APK jest w **Releases** (prawa kolumna repozytorium) albo w Actions → Artifacts.

## Instalacja na telefonie

Pobierz `MojGaraz-NN.apk`, otwórz go i zezwól na instalację z nieznanych źródeł. Aplikacja pojawi się jako „MójGaraż”. Kolejne wersje instaluj **na wierzch** (bez odinstalowywania): stały klucz podpisu w `keystore/` sprawia, że dane zostają. Od tej wersji numer kompilacji (`versionCode`) liczony jest z zegara, więc każdy nowy APK jest zawsze „nowszy” od poprzedniego, nawet gdy repozytorium założysz od nowa. Workflow dodatkowo sprawdza, czy APK jest podpisany kluczem z `keystore/`, i przerywa build, gdy nie jest.

Jednorazowo: jeśli na telefonie stoi jeszcze aplikacja zbudowana starszym schematem (inny klucz podpisu), Android odmówi nadpisania. Zrób kopię (Ustawienia → Zapisz plik), odinstaluj starą wersję i zainstaluj tę. Od następnej aktualizacji działa już „na wierzch”.

## Zapisy plików (Dokumenty/MójGaraż)

- Dane robocze są w pamięci aplikacji (localStorage w WebView). „Wyczyść dane” w ustawieniach Androida je kasuje.
- **Kopie `.json` zapisują się po cichu** do `Dokumenty/MójGaraż/`: automatyczny zapis po każdej zmianie (`mojgaraz_dane.json`) i przycisk „Zapisz plik” w Ustawieniach (`mojgaraz_backup_<data>.json`). Żadnych okien i komunikatów o sukcesie. Okno z komunikatem pojawia się tylko przy błędzie.
- **Raporty PDF** (dla kupującego) też zapisują się do `Dokumenty/MójGaraż/` (z krótkim komunikatem, gdzie leży plik).
- Pliki **kalendarza `.ics`** otwierają się przez okno „Udostępnij / Otwórz” (wybierasz aplikację Kalendarz).
- Zapis idzie przez własną wtyczkę `SfSave` (MediaStore, oficjalny sposób Androida 10+, bez uprawnień do plików); zapasowo działa wtyczka Filesystem. Gdyby wtyczka SfSave się nie skompilowała, workflow sam zbuduje APK bez niej.
- Plik `.bak` to poprzednia wersja zapisu. `przed-nadpisaniem_…` powstaje, gdy nowy zapis jest wyraźnie mniejszy od poprzedniego (np. po wyczyszczeniu danych).
- **Odtworzenie:** gdy aplikacja jest pusta (nowa instalacja albo „Wyczyść dane”), a w `Dokumenty/MójGaraż` leży kopia, aplikacja przy starcie proponuje jej wczytanie i pokazuje zwykłe okno „Wczytać kopię?”. Po **odinstalowaniu** Android 11+ może nie pozwolić nowej instalacji odczytać starego pliku samej. Wtedy użyj Ustawienia → Kopia zapasowa → Wczytaj i wskaż plik.

## Kalendarz (dolna belka)

- Ikona **Kalendarz** otwiera widok miesiąca. Przesuwasz palcem w lewo/prawo albo strzałkami; dotknięcie nazwy miesiąca otwiera wybór miesiąca i roku. „Dziś” wraca do bieżącego dnia.
- Dni z terminami mają kropki: czerwona = po terminie, pomarańczowa = wkrótce, niebieska = zaplanowane, pusta niebieska = szacunek z przebiegu (km).
- Dotknięcie dnia pokazuje poniżej szczegóły. Dotknięcie wpisu otwiera jego edycję: dokument (OC, przegląd…), wpis z przypomnieniem albo własne przypomnienie, gdzie zmienisz nazwę i datę. Pozycja z planu serwisowego ma menu: wpisz wykonanie, przypomnij w innym dniu, zmień interwał.
- **+ Przypomnienie** dodaje własne przypomnienie na wybrany dzień (opcjonalnie przypisane do auta). Ptaszek oznacza je jako wykonane.
- Zaległe terminy są też na liście dla dzisiejszego dnia.

## Powiadomienia push

- To prawdziwe powiadomienia Androida planowane z wyprzedzeniem. Przychodzą także przy zamkniętej aplikacji. **Aplikacja nie pokazuje już żadnych powiadomień przy otwieraniu ani zamykaniu.**
- **Godzinę** ustawiasz w Ustawieniach → Powiadomienia o terminach. Zmiana przelicza cały plan.
- Dokumenty (OC, AC, przegląd): od zapasu czasu ustawionego przy dokumencie (7, 14, 21 lub 28 dni), potem co tydzień, 3 dni, dzień przed, w dniu terminu, a po terminie 1, 2, 3, 7, 14, 21, 28, 35 i 42 dni po.
- Plan serwisowy i przypomnienia z wpisów: 14, 7, 3, 1 dzień przed, w dniu terminu i 3, 7, 14, 28 dni po. Pozycje liczone od przebiegu dostają datę szacunkową (30, 14, 7 dni przed, w dniu, 7, 14, 28 dni po) z dopiskiem „ok.”.
- Własne przypomnienia: tydzień przed, dzień przed, w dniu, 1 i 3 dni po.
- Powiadomienia z tego samego dnia łączą się w jedno. Dotknięcie powiadomienia otwiera Kalendarz na dniu terminu. Powiadomienia zostają na pasku, dopóki ich nie zamkniesz.
- Plan obejmuje 400 dni (do 150 powiadomień) i odświeża się po każdej zmianie danych oraz godziny. „Powiadomienie testowe” pokazuje je od razu, a „Test push za 1 min” sprawdza dostarczenie przy zamkniętej aplikacji.
- Android może wstrzymywać zaplanowane powiadomienia aplikacjom z włączoną oszczędnością baterii. Jeśli któreś nie przyjdzie: Ustawienia Androida → Aplikacje → MójGaraż → Bateria → Bez ograniczeń.
- Wyłączysz je w Ustawieniach → Powiadomienia o terminach (albo w ustawieniach Androida dla aplikacji).

## Odnowienie dokumentu jednym dotknięciem

W oknie dokumentu (OC, AC, przegląd) i w jego menu na osi czasu jest **Odnowiono: wpisz nowy okres**. Otwiera się nowy dokument z tym samym rodzajem i ubezpieczycielem. Okres OC i AC zaczyna się dzień po poprzednim i trwa tyle samo, a przegląd liczy się od dziś. Numer polisy i koszt zostają puste. Po zapisaniu stary dokument trafia do archiwum.

## Drobne ulepszenia wpisów i powiadomień

- Gdy w jednym dniu przypada kilka terminów, powiadomienie ma tytuł „pierwszy termin i jeszcze N”, a po rozwinięciu każdy termin jest w osobnym wierszu.
- W formularzu wpisu pod notatkami są podpowiedzi „Z poprzednich wpisów” (najpierw te z tym samym rodzajem serwisu); dotknięcie wstawia tekst. Przy wyborze kilku rodzajów serwisu pod kosztem jest przypomnienie, że to jeden koszt całej wizyty.
- Wyszukiwarka na osi czasu szuka też po kosztach (oprócz rodzaju, notatek, daty i przebiegu).

## Logo marki

Marka jest początkiem nazwy auta: wpisujesz ją w polu „Marka i model”, po pierwszych literach pojawiają się pasujące marki z logo (72 marki dostępne w Europie), wybierasz jedną i dopisujesz model w tym samym polu. Marki spoza listy nie da się zapisać. Logo pokazuje się w rogu zdjęcia auta. Logo pochodzą z paczki `brand-logos` (licencja MIT), zmniejszone i wbudowane w `src/index.html`.

## Przypomnienia, rodzaje serwisów i gesty

- **Ustawienia → Wszystkie przypomnienia**: jedna lista dla każdego auta (dokumenty, plan serwisowy, własne i z wpisów) z regułą („powtarzaj co 15 000 km”), stanem i harmonogramem push. Dotknięcie pozycji otwiera jej edycję.
- **Ustawienia → Rodzaje serwisów**: lista podpowiedzi przy wpisywaniu serwisu, z dodawaniem i usuwaniem. W formularzu wpisu wpisujesz słowo i dostajesz podpowiedzi; kilka rodzajów oddzielasz przecinkiem.
- **Kalendarz**: czerwona data = termin (kursywa = szacunek z przebiegu), niebieska = dzień, w którym przyjdzie przypomnienie.
- **Gest Wstecz**: przesunięcie palcem od lewej krawędzi ekranu w prawo zamyka bieżące okno, tak jak przycisk Wstecz.
- **Dokładne alarmy**: Ustawienia → Powiadomienia pokazują, czy Android pozwala na punktualne powiadomienia, i dają przycisk do ich włączenia.

## Przycisk Wstecz i edycja przypomnień

- **Wstecz** (przycisk Androida lub gest od lewej krawędzi): zamyka bieżące okno, potem wraca z auta i z Kalendarza do Garażu. Dopiero w Garażu pierwsze Wstecz pokazuje „Naciśnij Wstecz jeszcze raz, aby wyjść”, a drugie (w ciągu 2 s) zamyka aplikację. Wymaga wtyczki `@capacitor/app` (dopisana do `package.json`).
- **Okna nakładają się we właściwej kolejności**: edycja otwarta z Ustawień → Wszystkie przypomnienia pojawia się na wierzchu.
- **Kalendarz**: dotknięcie niebieskiego dnia pokazuje, o jakim terminie przypomni push tego dnia. Przy każdej pozycji jest menu ⋮: edytuj, oznacz jako wykonane, odnowiono (dokumenty), usuń (z pytaniem „Czy na pewno?” i „Cofnij”). To samo menu jest na liście Ustawienia → Wszystkie przypomnienia.

## Dni przypomnień wybierane z kalendarza

W oknie dokumentu (OC, AC, przegląd i inne) oraz własnego przypomnienia jest przycisk **Wybierz dni**. Otwiera kalendarz, w którym dotykasz dni, w których ma przyjść push (można wiele, także dni po terminie). Czerwona ramka to termin. „Domyślne” przywraca standardowy harmonogram, „Wyczyść” usuwa wybór. Wybór jest zapisany względem terminu, więc po zmianie daty terminu przypomnienia przesuwają się razem z nim. Dni z przeszłości są nieaktywne. Przy dokumencie w trybie podglądu ten sam kalendarz otwiera dzwonek w nagłówku. Lista Ustawienia → Wszystkie przypomnienia pokazuje konkretne daty push. Plan serwisowy i przypomnienia z wpisów nadal używają standardowego harmonogramu.

Dolna belka ma kolejność: Garaż, Dodaj wpis, Kalendarz, Ustawienia.

## Przypomnienia wg przebiegu (np. wymiana oleju)

Pozycje z interwałem w km nie mają sztywnej daty. Push wychodzi wtedy, gdy wg Twojego ostatniego przebiegu i tempa jazdy zostaje ok. **2000, 1000, 500 i 0 km** (a po przekroczeniu: 500 i 1500 km), z treścią „zostało ok. 1 000 km (szac. 01.05)”. Daty tych progów aplikacja przelicza za każdym razem, gdy zmienią się dane, czyli po wpisaniu nowego przebiegu albo wpisu z przebiegiem plan push przesuwa się sam. Telefon nie zna przebiegu sam z siebie, więc dokładność zależy od tego, jak świeży jest ostatni wpis.


## Usuwanie auta

Menu auta (⋮ na karcie auta lub w widoku auta) ma pozycję **Usuń auto…** na dole, w kolorze czerwonym. Pyta „Czy na pewno usunąć auto?”, a zaraz po usunięciu działa „Cofnij”. W oknie edycji auta przycisku usuwania nie ma.

## Aktualizacja aplikacji nowym plikiem HTML

(Opcja „Wczytaj nowy plik HTML” została ukryta w Ustawieniach; aktualizujesz nowym APK z GitHuba.)

**Sposób 1: bez GitHuba, prosto w aplikacji**
1. Pobierz nowy `index.html` na telefon.
2. Ustawienia → sekcja **Aplikacja** → **Wczytaj nowy plik HTML**, wybierz plik.
3. Aplikacja sprawdzi plik, zapyta o potwierdzenie i uruchomi się ponownie z nowym kodem. Dane i ustawienia zostają.
- Plik jest uruchamiany, dopóki nie zainstalujesz nowszego APK. Nowszy APK (wyższa wersja `APP_VER`) sam porzuca wczytany plik.
- „Wróć do wersji wbudowanej” usuwa wczytany plik. Gdyby wczytany plik nie uruchomił się poprawnie, aplikacja po dwóch próbach sama do niego nie wraca.
- Plik zajmuje miejsce w pamięci aplikacji (ok. 0,4 MB). Przy bardzo dużej bazie ze zdjęciami może go zabraknąć: zrób kopię albo użyj sposobu 2.

**Sposób 2: nowy APK z GitHuba (trwała wersja)**
1. Podmień `src/index.html` w repozytorium na nowy plik (Add file → Upload files). Nic więcej nie zmieniaj: `www/` i dodatki Androida tworzy skrypt `scripts/build-www.py` przy buildzie.
2. GitHub zbuduje nowy APK. Zainstaluj go na wierzch starej aplikacji.

Nowy plik HTML to ten sam plik, którego używasz jako aplikacji PWA. Najlepiej, żeby miał podniesiony numer `APP_VER` w kodzie.

## Co w repozytorium

- `src/`: plik PWA (`index.html`), ikony, `manifest`, **`native-bridge.js`** (most: zapisy, powiadomienia, aktualizacja z pliku, odtworzenie).
- `scripts/build-www.py`: z `src/` robi `www/` (dokłada most i loader aktualizacji do `index.html`).
- `native/SfSavePlugin.java`: wtyczka zapisu do Dokumentów.
- `scripts/patch-android.sh`: numer wersji, podpis, ikony, uprawnienia (powiadomienia), kolor paska stanu.
- `resources/`, `assets/`: ikona aplikacji, mała ikona powiadomień, ekran startowy.
- Zależności od kodu HTML (nowe wersje muszą je zachować): funkcja `download()`, elementy `#toast`, `#toastMsg`, `#setBody`, `#imp`, `#autoExpInfo`, `#instInfo`, zmienne `APP_VER` i `db`, funkcje `allItems`, `syncNotif`, `notifOn`, `renderSettings` oraz klucze `serwisDB` i `mgNotif`.

## Uwagi

- Klucz w `keystore/` jest przeznaczony do własnej instalacji (sideload), a nie do Google Play. Dlatego repozytorium ma być prywatne.
- Lokalnie (Android Studio): `npm install`, `python3 scripts/build-www.py`, `npx cap add android`, `npx cap sync android`, `./scripts/patch-android.sh`, potem otwórz folder `android`.

## Audyt (v34)
- Naprawiono: „Dodaj do kalendarza” (eksport ICS) otwierał widok kalendarza – dwie warstwy miały to samo id.
- Naprawiono: import uszkodzonej/obcej kopii (null, tekst, złe pola) – teraz czytelny komunikat zamiast cichego błędu; migracja danych odporna na śmieci.

## Audyt UX (v35)
- Garaż: pod każdym autem widać najbliższy termin (np. „OC · Trasti · za 32 dni”).
- Widok auta: karta „Najbliższy termin” z przejściem do wszystkich przypomnień, także gdy nic nie jest pilne.
- Czytelniejsze nazwy przycisków („Rodzaje serwisów”, „Plan serwisowy auta”), większe pola dotyku (min. 40 px).

## Wydatki (v37)
- Rodzaj wydatku wpisuje się tak samo jak rodzaj serwisu: pisanie + podpowiedzi z listy, nowe nazwy zapamiętują się same.
- Lista wydatków edytowana w Ustawienia → „Rodzaje serwisów i wydatków”. Podpowiedzi notatek w wydatku pochodzą tylko z wydatków.

## Spójność formularzy (v38)
- Plan serwisowy: nazwę pozycji wpisuje się z podpowiedziami (jak w serwisie i wydatkach), bez wyświetlania całej listy przycisków.

## Audyt całościowy (v39)
- Walidacja: koszt (0–10 mln zł, bez ujemnych), przebieg (0–2 mln km), data (od 1990; data z przyszłości wymaga potwierdzenia) w serwisie, wydatku, przebiegu i dokumencie.
- Wyszukiwarka historii ignoruje polskie znaki („lozysk” znajdzie „łożysk”).
- Teksty o „przeglądarce/Chrome/Pobrane” zastąpione neutralnymi.

## Terminy, przypomnienia push i kalendarz lokalny (v46)

* **Bez Google.** Kalendarz jest w całości lokalny: działa bez logowania i bez internetu. Nie ma Google OAuth, Calendar API ani projektu Google Cloud.
* **Jedno okno „Przypomnienia push”** dla każdego terminu (dzwonek przy wierszu, szczegóły dokumentu, kalendarz, menu ⋮, Ustawienia → „Terminy i przypomnienia”, formularze). Dni push (wiele, własne, presety), wyłączenie push, szybkie akcje: edycja/zmiana daty, odnowienie, wykonane.
* **Dodaj wpis:** Serwis, Wydatek, Przegląd, Ubezp. OC, Licznik. Przegląd i OC mają ekran statusu, odnowienie i historię. Licznik ma notatkę i historię z usuwaniem.
* **Kopia zapasowa = cały kalendarz.** Plik `mojgaraz_dane.json` (Dokumenty/MójGaraż) to cała baza: auta, dokumenty z historią poprzednich przeglądów i polis (`arch`), wpisy serwisowe, własne przypomnienia, stany licznika oraz `rcfg` – ustawienia push każdego terminu (`dni`, `push:false`). Pole `schema` wersjonuje plik. Starsze pliki (bez `rcfg`/`schema`) wczytują się normalnie.
* **Nowy telefon:** zainstaluj aplikację → Ustawienia → wczytaj plik kopii (z potwierdzeniem zastąpienia danych) → aplikacja sama planuje od nowa przyszłe powiadomienia (przeszłe pomija, bez duplikatów). Powiadomienia trzeba włączyć na nowym telefonie i przyznać zgodę – aplikacja przypomni o tym po imporcie.
* **Import:** walidacja struktury, pominięcie duplikatów id w pliku, porządkowanie ustawień push; ponowny import tego samego pliku zastępuje dane, nie dubluje.

## Kalendarz telefonu i kolory terminów (v48)

* Ikona kalendarza w oknie „Przypomnienia” decyduje, czy termin jest widoczny w kalendarzu aplikacji **i** w kalendarzu telefonu. Kalendarz „MójGaraż” w telefonie włączasz w Ustawieniach (zgoda na kalendarz); każda zmiana terminu, dni przypomnień lub ukrycie/pokazanie od razu się w nim odświeża. Działa lokalnie, bez Google i bez internetu. Wtyczka SfCal (gdyby się nie skompilowała, workflow buduje bez niej).
* Im bliżej terminu, tym bardziej czerwony dzwonek i napis na pulpicie oraz tło karty „Najbliższy termin” w widoku auta (≤30 dni bursztynowy, ≤14 pomarańczowy, ≤7 dni i po terminie czerwone tło).

## Ikony 🔔📅 (v49)
Dwie małe ikony (bez opisów, wypełniają się kolorem gdy aktywne) w prawym górnym rogu okna terminu, na ekranie Przegląd/OC, na liście terminów i na pulpicie. Ta sama logika wszędzie: 1. dotknięcie = panel edycji, 2. = wyłącz (zapamiętuje dni), 3. = włącz + panel. Usunięto starą ikonę „Dodaj do kalendarza” (ICS) z okien Serwis i Dokument oraz z menu.

## v50
- „za 111 dni” nie łamie się w środku (twarde spacje).
- Ikony 🔔📅 także na wierszach w Kalendarzu; w oknach Dokument i Serwis jeden zestaw u góry (usunięty duży przycisk „Przypomnienia push…” i stary dzwonek).
- Ikona zegara w oknie Serwis = interwał tego serwisu (km / miesiące, „Przebieg od serwisu”, usuń); aktywna ma wypełnione tło. „Zmień interwał” w panelu terminu też otwiera to okno.
- Ikona kalendarza dotyczy kalendarza telefonu (Android). Kalendarz w aplikacji pokazuje zawsze wszystko. Do kalendarza telefonu trafiają teraz także progi z interwałów (zostało ok. 2000/1000/500 km, czas na serwis).
- Usunięty baner „Zrób kopię zapasową”; kopia pliku robi się automatycznie (też przy starcie, gdy ostatnia ma >7 dni).
