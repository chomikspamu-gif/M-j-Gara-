# MójGaraż: aplikacja na Androida

Ta sama aplikacja co w przeglądarce (`src/index.html`), opakowana w Capacitor. GitHub zbuduje z niej plik **APK**, który zainstalujesz na telefonie.

## Jak zbudować na GitHubie

1. Załóż na github.com **prywatne** repozytorium (np. `mojgaraz`). Ma być prywatne, bo w środku jest klucz podpisu aplikacji.
2. Wgraj do niego całą zawartość tego zipa, razem z ukrytym folderem `.github`.
   - Przez stronę: „Add file → Upload files” i przeciągnij pliki po rozpakowaniu. Jeśli `.github` się nie wgra, wybierz „Add file → Create new file”, wpisz nazwę `.github/workflows/android.yml` i wklej zawartość tego pliku z zipa.
3. Wejdź w **Actions → Build Android APK**. Build startuje sam po wgraniu plików (albo „Run workflow”). Trwa kilka minut.
4. Gdy zrobi się zielony, plik APK jest w **Releases** (prawa kolumna repozytorium) albo w Actions → Artifacts.

## Instalacja na telefonie

Pobierz `MojGaraz-NN.apk`, otwórz go i zezwól na instalację z nieznanych źródeł. Aplikacja pojawi się jako „MójGaraż”. Kolejne wersje instaluj **na wierzch** (bez odinstalowywania): stały klucz podpisu w `keystore/` sprawia, że dane zostają.

## Zapisy plików (Dokumenty/MójGaraż)

- Dane robocze są w pamięci aplikacji (localStorage w WebView). „Wyczyść dane” w ustawieniach Androida je kasuje.
- **Kopie `.json` zapisują się po cichu** do `Dokumenty/MójGaraż/`: automatyczny zapis po każdej zmianie (`mojgaraz_dane.json`) i przycisk „Zapisz plik” w Ustawieniach (`mojgaraz_backup_<data>.json`). Żadnych okien i komunikatów o sukcesie. Okno z komunikatem pojawia się tylko przy błędzie.
- **Raporty PDF** (dla kupującego) też zapisują się do `Dokumenty/MójGaraż/` (z krótkim komunikatem, gdzie leży plik).
- Pliki **kalendarza `.ics`** otwierają się przez okno „Udostępnij / Otwórz” (wybierasz aplikację Kalendarz).
- Zapis idzie przez własną wtyczkę `SfSave` (MediaStore, oficjalny sposób Androida 10+, bez uprawnień do plików); zapasowo działa wtyczka Filesystem. Gdyby wtyczka SfSave się nie skompilowała, workflow sam zbuduje APK bez niej.
- Plik `.bak` to poprzednia wersja zapisu. `przed-nadpisaniem_…` powstaje, gdy nowy zapis jest wyraźnie mniejszy od poprzedniego (np. po wyczyszczeniu danych).
- **Odtworzenie:** gdy aplikacja jest pusta (nowa instalacja albo „Wyczyść dane”), a w `Dokumenty/MójGaraż` leży kopia, aplikacja przy starcie proponuje jej wczytanie i pokazuje zwykłe okno „Wczytać kopię?”. Po **odinstalowaniu** Android 11+ może nie pozwolić nowej instalacji odczytać starego pliku samej. Wtedy użyj Ustawienia → Kopia zapasowa → Wczytaj i wskaż plik.

## Powiadomienia o terminach

- Aplikacja używa **prawdziwych powiadomień Androida** (pasek powiadomień i kropka przy ikonie), a nie powiadomień przeglądarki. Przy pierwszym uruchomieniu poprosi o zgodę (Android 13+) i włączy powiadomienia o terminach.
- Cała logika terminów (serwis, przegląd, OC/AC, przypomnienia, interwały) jest ta z aplikacji HTML. Przy zejściu aplikacji do tła pokazuje się zbiorcze powiadomienie „MójGaraż: N terminów”, gdy coś jest po terminie albo wkrótce.
- Dodatkowo aplikacja **planuje powiadomienia na przyszłość** (o 9:00): za 14, 7, 3 i 1 dzień przed terminem, w dniu terminu i po terminie (3, 7, 14, 30 dni). Przychodzą także wtedy, gdy aplikacja jest zamknięta. Plan odświeża się po każdej zmianie danych. Maksymalnie 60 powiadomień na 150 dni.
- Terminy liczone od przebiegu (km) mają datę tylko szacunkową, więc dla nich działa zwykłe powiadomienie przy zejściu aplikacji do tła.
- Po otwarciu aplikacji stare przypomnienia z paska znikają.
- Wyłączysz je w Ustawieniach → Powiadomienia o terminach (albo w ustawieniach Androida dla aplikacji). Przycisk „Wyślij powiadomienie testowe” sprawdzi, czy działają.

## Aktualizacja aplikacji nowym plikiem HTML

**Sposób 1: bez GitHuba, prosto w aplikacji**
1. Pobierz nowy `index.html` na telefon.
2. Ustawienia → sekcja **Aplikacja** → **Wczytaj nowy plik HTML**, wybierz plik.
3. Aplikacja sprawdzi plik, zapyta o potwierdzenie i uruchomi się ponownie z nowym kodem. Dane i ustawienia zostają.
- Plik jest uruchamiany, dopóki nie zainstalujesz nowszego APK. Nowszy APK (wyższa wersja `APP_VER`) sam porzuca wczytany plik.
- „Wróć do wersji wbudowanej” usuwa wczytany plik. Gdyby wczytany plik nie uruchomił się poprawnie, aplikacja po dwóch próbach sama do niego nie wraca.
- Plik zajmuje miejsce w pamięci aplikacji (ok. 0,4 MB). Przy bardzo dużej bazie ze zdjęciami może go zabraknąć: zrób kopię albo użyj sposobu 2.

**Sposób 2: nowy APK z GitHuba (trwała wersja)**
1. Podmień `src/index.html` w repozytorium na nowy plik (Add file → Upload files). Nic więcej nie zmieniaj: `www/` i dodatki Androida tworzy skrypt `scripts/build-www.py` przy buildzie.
2. GitHub zbuduje nowy APK. Zainstaluj go na wierzch starej aplikacji.

Nowy plik HTML to ten sam plik, którego używasz jako aplikacji PWA. Najlepiej, żeby miał podniesiony numer `APP_VER` w kodzie.

## Co w repozytorium

- `src/`: plik PWA (`index.html`), ikony, `manifest`, **`native-bridge.js`** (most: zapisy, powiadomienia, aktualizacja z pliku, odtworzenie).
- `scripts/build-www.py`: z `src/` robi `www/` (dokłada most i loader aktualizacji do `index.html`).
- `native/SfSavePlugin.java`: wtyczka zapisu do Dokumentów.
- `scripts/patch-android.sh`: numer wersji, podpis, ikony, uprawnienia (powiadomienia), kolor paska stanu.
- `resources/`, `assets/`: ikona aplikacji, mała ikona powiadomień, ekran startowy.
- Zależności od kodu HTML (nowe wersje muszą je zachować): funkcja `download()`, elementy `#toast`, `#toastMsg`, `#setBody`, `#imp`, `#autoExpInfo`, `#instInfo`, zmienne `APP_VER` i `db`, funkcje `allItems`, `syncNotif`, `notifOn`, `renderSettings` oraz klucze `serwisDB` i `mgNotif`.

## Uwagi

- Klucz w `keystore/` jest przeznaczony do własnej instalacji (sideload), a nie do Google Play. Dlatego repozytorium ma być prywatne.
- Lokalnie (Android Studio): `npm install`, `python3 scripts/build-www.py`, `npx cap add android`, `npx cap sync android`, `./scripts/patch-android.sh`, potem otwórz folder `android`.
