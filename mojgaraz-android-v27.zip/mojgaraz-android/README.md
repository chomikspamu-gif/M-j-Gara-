# MójGaraż: aplikacja na Androida

Ta sama aplikacja co w przeglądarce (`src/index.html`), opakowana w Capacitor. GitHub zbuduje z niej plik **APK**, który zainstalujesz na telefonie.

## Jak zbudować na GitHubie

1. Załóż na github.com **prywatne** repozytorium (np. `mojgaraz`). Ma być prywatne, bo w środku jest klucz podpisu aplikacji.
2. Wgraj do niego całą zawartość tego zipa, razem z ukrytym folderem `.github`.
   - Przez stronę: „Add file → Upload files” i przeciągnij pliki po rozpakowaniu. Jeśli `.github` się nie wgra, wybierz „Add file → Create new file”, wpisz nazwę `.github/workflows/android.yml` i wklej zawartość tego pliku z zipa.
3. Wejdź w **Actions → Build Android APK**. Build startuje sam po wgraniu plików (albo „Run workflow”). Trwa kilka minut.
4. Gdy zrobi się zielony, plik APK jest w **Releases** (prawa kolumna repozytorium) albo w Actions → Artifacts.

## Instalacja na telefonie

Pobierz `MojGaraz-NN.apk`, otwórz go i zezwól na instalację z nieznanych źródeł. Aplikacja pojawi się jako „MójGaraż”. Kolejne wersje instaluj **na wierzch** (bez odinstalowywania): stały klucz podpisu w `keystore/` sprawia, że dane zostają. Od tej wersji numer kompilacji (`versionCode`) liczony jest z zegara, więc każdy nowy APK jest zawsze „nowszy” od poprzedniego, nawet gdy repozytorium założysz od nowa. Workflow dodatkowo sprawdza, czy APK jest podpisany kluczem z `keystore/`, i przerywa build, gdy nie jest.

Jednorazowo: jeśli na telefonie stoi jeszcze aplikacja zbudowana starszym schematem (inny klucz podpisu), Android odmówi nadpisania. Zrób kopię (Ustawienia → Zapisz plik), odinstaluj starą wersję i zainstaluj tę. Od następnej aktualizacji działa już „na wierzch”.

## Zapisy plików (Dokumenty/MójGaraż)

- Dane robocze są w pamięci aplikacji (localStorage w WebView). „Wyczyść dane” w ustawieniach Androida je kasuje.
- **Kopie `.json` zapisują się po cichu** do `Dokumenty/MójGaraż/`: automatyczny zapis po każdej zmianie (`mojgaraz_dane.json`) i przycisk „Zapisz plik” w Ustawieniach (`mojgaraz_backup_<data>.json`). Żadnych okien i komunikatów o sukcesie. Okno z komunikatem pojawia się tylko przy błędzie.
- **Raporty PDF** (dla kupującego) też zapisują się do `Dokumenty/MójGaraż/` (z krótkim komunikatem, gdzie leży plik).
- Pliki **kalendarza `.ics`** otwierają się przez okno „Udostępnij / Otwórz” (wybierasz aplikację Kalendarz).
- Zapis idzie przez własną wtyczkę `SfSave` (MediaStore, oficjalny sposób Androida 10+, bez uprawnień do plików); zapasowo działa wtyczka Filesystem. Gdyby wtyczka SfSave się nie skompilowała, workflow sam zbuduje APK bez niej.
- Plik `.bak` to poprzednia wersja zapisu. `przed-nadpisaniem_…` powstaje, gdy nowy zapis jest wyraźnie mniejszy od poprzedniego (np. po wyczyszczeniu danych).
- **Odtworzenie:** gdy aplikacja jest pusta (nowa instalacja albo „Wyczyść dane”), a w `Dokumenty/MójGaraż` leży kopia, aplikacja przy starcie proponuje jej wczytanie i pokazuje zwykłe okno „Wczytać kopię?”. Po **odinstalowaniu** Android 11+ może nie pozwolić nowej instalacji odczytać starego pliku samej. Wtedy użyj Ustawienia → Kopia zapasowa → Wczytaj i wskaż plik.

## Kalendarz (dolna belka)

- Ikona **Kalendarz** otwiera widok miesiąca. Przesuwasz palcem w lewo/prawo albo strzałkami; dotknięcie nazwy miesiąca otwiera wybór miesiąca i roku. „Dziś” wraca do bieżącego dnia.
- Dni z terminami mają kropki: czerwona = po terminie, pomarańczowa = wkrótce, niebieska = zaplanowane, pusta niebieska = szacunek z przebiegu (km).
- Dotknięcie dnia pokazuje poniżej szczegóły. Dotknięcie wpisu otwiera jego edycję: dokument (OC, przegląd…), wpis z przypomnieniem albo własne przypomnienie, gdzie zmienisz nazwę i datę. Pozycja z planu serwisowego ma menu: wpisz wykonanie, przypomnij w innym dniu, zmień interwał.
- **+ Przypomnienie** dodaje własne przypomnienie na wybrany dzień (opcjonalnie przypisane do auta). Ptaszek oznacza je jako wykonane.
- Zaległe terminy są też na liście dla dzisiejszego dnia.

## Powiadomienia push

- To prawdziwe powiadomienia Androida planowane z wyprzedzeniem. Przychodzą także przy zamkniętej aplikacji. **Aplikacja nie pokazuje już żadnych powiadomień przy otwieraniu ani zamykaniu.**
- **Godzinę** ustawiasz w Ustawieniach → Powiadomienia o terminach. Zmiana przelicza cały plan.
- Dokumenty (OC, AC, przegląd): od zapasu czasu ustawionego przy dokumencie (7, 14, 21 lub 28 dni), potem co tydzień, 3 dni, dzień przed, w dniu terminu, a po terminie 1, 2, 3, 7, 14, 21, 28, 35 i 42 dni po.
- Plan serwisowy i przypomnienia z wpisów: 14, 7, 3, 1 dzień przed, w dniu terminu i 3, 7, 14, 28 dni po. Pozycje liczone od przebiegu dostają datę szacunkową (30, 14, 7 dni przed, w dniu, 7, 14, 28 dni po) z dopiskiem „ok.”.
- Własne przypomnienia: tydzień przed, dzień przed, w dniu, 1 i 3 dni po.
- Powiadomienia z tego samego dnia łączą się w jedno. Dotknięcie powiadomienia otwiera Kalendarz na dniu terminu. Powiadomienia zostają na pasku, dopóki ich nie zamkniesz.
- Plan obejmuje 400 dni (do 150 powiadomień) i odświeża się po każdej zmianie danych oraz godziny. „Powiadomienie testowe” pokazuje je od razu, a „Test push za 1 min” sprawdza dostarczenie przy zamkniętej aplikacji.
- Android może wstrzymywać zaplanowane powiadomienia aplikacjom z włączoną oszczędnością baterii. Jeśli któreś nie przyjdzie: Ustawienia Androida → Aplikacje → MójGaraż → Bateria → Bez ograniczeń.
- Wyłączysz je w Ustawieniach → Powiadomienia o terminach (albo w ustawieniach Androida dla aplikacji).

## Odnowienie dokumentu jednym dotknięciem

W oknie dokumentu (OC, AC, przegląd) i w jego menu na osi czasu jest **Odnowiono: wpisz nowy okres**. Otwiera się nowy dokument z tym samym rodzajem i ubezpieczycielem. Okres OC i AC zaczyna się dzień po poprzednim i trwa tyle samo, a przegląd liczy się od dziś. Numer polisy i koszt zostają puste. Po zapisaniu stary dokument trafia do archiwum.

## Drobne ulepszenia wpisów i powiadomień

- Gdy w jednym dniu przypada kilka terminów, powiadomienie ma tytuł „pierwszy termin i jeszcze N”, a po rozwinięciu każdy termin jest w osobnym wierszu.
- W formularzu wpisu pod notatkami są podpowiedzi „Z poprzednich wpisów” (najpierw te z tym samym rodzajem serwisu); dotknięcie wstawia tekst. Przy wyborze kilku rodzajów serwisu pod kosztem jest przypomnienie, że to jeden koszt całej wizyty.
- Wyszukiwarka na osi czasu szuka też po kosztach (oprócz rodzaju, notatek, daty i przebiegu).

## Logo marki

Przy dodawaniu i edycji auta wybierasz markę z listy 72 marek dostępnych w Europie (z wyszukiwarką). Jej logo pokazuje się w rogu zdjęcia auta. Własne logo z pliku i dawne znaczki tekstowe usunięto; w istniejących autach zostaje wybrana marka. Logo pochodzą z paczki `brand-logos` (licencja MIT), zmniejszone i wbudowane w `src/index.html`.

## Usuwanie auta

Menu auta (⋮ na karcie auta lub w widoku auta) ma pozycję **Usuń auto…** na dole, w kolorze czerwonym. Pyta „Czy na pewno usunąć auto?”, a zaraz po usunięciu działa „Cofnij”. W oknie edycji auta przycisku usuwania nie ma.

## Aktualizacja aplikacji nowym plikiem HTML

**Sposób 1: bez GitHuba, prosto w aplikacji**
1. Pobierz nowy `index.html` na telefon.
2. Ustawienia → sekcja **Aplikacja** → **Wczytaj nowy plik HTML**, wybierz plik.
3. Aplikacja sprawdzi plik, zapyta o potwierdzenie i uruchomi się ponownie z nowym kodem. Dane i ustawienia zostają.
- Plik jest uruchamiany, dopóki nie zainstalujesz nowszego APK. Nowszy APK (wyższa wersja `APP_VER`) sam porzuca wczytany plik.
- „Wróć do wersji wbudowanej” usuwa wczytany plik. Gdyby wczytany plik nie uruchomił się poprawnie, aplikacja po dwóch próbach sama do niego nie wraca.
- Plik zajmuje miejsce w pamięci aplikacji (ok. 0,4 MB). Przy bardzo dużej bazie ze zdjęciami może go zabraknąć: zrób kopię albo użyj sposobu 2.

**Sposób 2: nowy APK z GitHuba (trwała wersja)**
1. Podmień `src/index.html` w repozytorium na nowy plik (Add file → Upload files). Nic więcej nie zmieniaj: `www/` i dodatki Androida tworzy skrypt `scripts/build-www.py` przy buildzie.
2. GitHub zbuduje nowy APK. Zainstaluj go na wierzch starej aplikacji.

Nowy plik HTML to ten sam plik, którego używasz jako aplikacji PWA. Najlepiej, żeby miał podniesiony numer `APP_VER` w kodzie.

## Co w repozytorium

- `src/`: plik PWA (`index.html`), ikony, `manifest`, **`native-bridge.js`** (most: zapisy, powiadomienia, aktualizacja z pliku, odtworzenie).
- `scripts/build-www.py`: z `src/` robi `www/` (dokłada most i loader aktualizacji do `index.html`).
- `native/SfSavePlugin.java`: wtyczka zapisu do Dokumentów.
- `scripts/patch-android.sh`: numer wersji, podpis, ikony, uprawnienia (powiadomienia), kolor paska stanu.
- `resources/`, `assets/`: ikona aplikacji, mała ikona powiadomień, ekran startowy.
- Zależności od kodu HTML (nowe wersje muszą je zachować): funkcja `download()`, elementy `#toast`, `#toastMsg`, `#setBody`, `#imp`, `#autoExpInfo`, `#instInfo`, zmienne `APP_VER` i `db`, funkcje `allItems`, `syncNotif`, `notifOn`, `renderSettings` oraz klucze `serwisDB` i `mgNotif`.

## Uwagi

- Klucz w `keystore/` jest przeznaczony do własnej instalacji (sideload), a nie do Google Play. Dlatego repozytorium ma być prywatne.
- Lokalnie (Android Studio): `npm install`, `python3 scripts/build-www.py`, `npx cap add android`, `npx cap sync android`, `./scripts/patch-android.sh`, potem otwórz folder `android`.
