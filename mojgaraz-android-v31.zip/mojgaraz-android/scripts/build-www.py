#!/usr/bin/env python3
"""Buduje www/ z src/: bierze oryginalny plik PWA (src/index.html) i dokłada do <head>:
   1) meta mg-app-ver (wersja wbudowana, z APP_VER w pliku),
   2) <script src="native-bridge.js"> (most Androida: zapis plików, powiadomienia, aktualizacja z pliku),
   3) loader: jeśli w pamięci aplikacji jest NOWSZA wersja wczytana z pliku (Ustawienia → Aplikacja Android), uruchamia ją zamiast wbudowanej.
Aby wydać nową wersję: podmień src/index.html na nowy plik PWA i wgraj na GitHub. Nic więcej nie trzeba zmieniać."""
import re, shutil, sys, pathlib

root = pathlib.Path(__file__).resolve().parent.parent
src, www = root / 'src', root / 'www'
html = (src / 'index.html').read_text(encoding='utf-8')
m = re.search(r'APP_VER\s*=\s*["\']([^"\']+)["\']', html)
ver = m.group(1) if m else '0'

LOADER = r'''<script>
/* mg-loader: nowsza wersja aplikacji wczytana z pliku (Ustawienia → Aplikacja Android) uruchamia się zamiast wbudowanej.
   Wersja wbudowana w APK o równym lub wyższym numerze wygrywa i usuwa wczytany plik. Parametr ?noovr pomija wczytany plik. */
(function(){
  var K='mg_app_override',KM='mg_app_override_meta',KT='mg_app_override_try';
  function cmp(a,b){var x=String(a).split('.'),y=String(b).split('.');for(var i=0;i<Math.max(x.length,y.length);i++){var p=parseInt(x[i],10)||0,q=parseInt(y[i],10)||0;if(p!==q)return p>q?1:-1}return 0}
  function drop(){try{localStorage.removeItem(K);localStorage.removeItem(KM);localStorage.removeItem(KT)}catch(e){}}
  try{
    if(window.__mgOvr)return;
    if(/[?&]noovr(=|&|$)/.test(location.search))return;
    var BASE=(document.querySelector('meta[name=mg-app-ver]')||{}).content||'0';
    window.__mgBase=BASE;
    var raw=localStorage.getItem(KM);if(!raw)return;
    var meta=JSON.parse(raw);
    var ok=meta&&(cmp(meta.ver,BASE)>0||(meta.force&&meta.base===BASE));
    if(!ok){drop();return}
    var tries=parseInt(localStorage.getItem(KT),10)||0;
    if(tries>=2){window.__mgOvrFailed=meta;drop();return}
    var html=localStorage.getItem(K);if(!html)return;
    localStorage.setItem(KT,String(tries+1));
    var doc=new DOMParser().parseFromString(html,'text/html'),root=doc.documentElement,list=[].slice.call(root.querySelectorAll('script'));
    window.__mgOvr=meta.ver;window.__mgOvrMeta=meta;
    document.replaceChild(document.adoptNode(root),document.documentElement);
    for(var i=0;i<list.length;i++){
      var o=list[i],n=document.createElement('script');
      for(var j=0;j<o.attributes.length;j++)n.setAttribute(o.attributes[j].name,o.attributes[j].value);
      n.text=o.text;o.parentNode.replaceChild(n,o);
    }
    setTimeout(function(){try{if(!document.getElementById('mSet')){localStorage.setItem(KT,'2');location.reload()}else{localStorage.removeItem(KT)}}catch(e){}},6000);
  }catch(e){try{localStorage.removeItem(KT)}catch(x){}window.__mgOvr=0}
})();
</script>
'''

inject = ('<meta name="mg-app-ver" content="%s">\n<script src="native-bridge.js"></script>\n%s' % (ver, LOADER))
if '<head>' in html:
    html = html.replace('<head>', '<head>\n' + inject, 1)
else:
    html = re.sub(r'(<head[^>]*>)', lambda mm: mm.group(1) + '\n' + inject, html, count=1)

www.mkdir(exist_ok=True)
(www / 'index.html').write_text(html, encoding='utf-8')
for f in src.iterdir():
    if f.name in ('index.html',) or f.name.startswith('.'):
        continue
    shutil.copy(f, www / f.name)
print('www/ gotowe: MójGaraż v%s (%d znaków)' % (ver, len(html)))
