#!/usr/bin/env bash
# Awaryjnie: usuwa wtyczkę SfSave (gdyby nie przeszła kompilacja), żeby APK i tak powstał. Zapis działa wtedy przez Filesystem.
set -euo pipefail
JAVA_DIR="android/app/src/main/java/pl/mojgaraz/app"
rm -f "$JAVA_DIR/SfSavePlugin.java"
cat > "$JAVA_DIR/MainActivity.java" <<'MAINACT'
package pl.mojgaraz.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
MAINACT
echo "SfSave usunięta (build awaryjny)"
