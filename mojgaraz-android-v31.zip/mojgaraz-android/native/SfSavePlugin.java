package pl.mojgaraz.app;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * Zapis plików do Dokumenty/MójGaraż przez MediaStore (oficjalny sposób Androida 10+, bez żadnych uprawnień do plików).
 * Wtyczka Filesystem pisze po zwykłych ścieżkach, co na nowszych Androidach kończy się błędem FILE_NOTCREATED i plikiem 0 B.
 */
@CapacitorPlugin(name = "SfSave")
public class SfSavePlugin extends Plugin {

    private static final String COL_ID = "_id";
    private static final String COL_NAME = "_display_name";
    private static final String COL_REL = "relative_path";
    private static final String COL_SIZE = "_size";
    private static final String COL_MIME = "mime_type";

    private Uri collection() {
        return MediaStore.Files.getContentUri("external");
    }

    private long findId(ContentResolver cr, String name, String rel) {
        Cursor c = null;
        try {
            c = cr.query(collection(), new String[]{COL_ID},
                    COL_NAME + "=? AND " + COL_REL + "=?", new String[]{name, rel}, null);
            if (c != null && c.moveToFirst()) {
                return c.getLong(0);
            }
        } catch (Exception e) {
            // brak wyniku
        } finally {
            if (c != null) {
                c.close();
            }
        }
        return -1L;
    }

    private long sizeOf(ContentResolver cr, long id) {
        Cursor c = null;
        try {
            c = cr.query(ContentUris.withAppendedId(collection(), id), new String[]{COL_SIZE}, null, null, null);
            if (c != null && c.moveToFirst()) {
                return c.getLong(0);
            }
        } catch (Exception e) {
            // brak wyniku
        } finally {
            if (c != null) {
                c.close();
            }
        }
        return 0L;
    }

    private Uri insertNew(ContentResolver cr, String name, String folder, String mime) {
        ContentValues v = new ContentValues();
        v.put(COL_NAME, name);
        v.put(COL_MIME, mime);
        v.put(COL_REL, "Documents/" + folder);
        return cr.insert(collection(), v);
    }

    private void copyFile(ContentResolver cr, Uri src, String destName, String folder, String mime) {
        InputStream in = null;
        OutputStream out = null;
        try {
            String rel = "Documents/" + folder + "/";
            long id = findId(cr, destName, rel);
            Uri dest;
            if (id >= 0) {
                dest = ContentUris.withAppendedId(collection(), id);
            } else {
                dest = insertNew(cr, destName, folder, mime);
            }
            if (dest == null) {
                return;
            }
            in = cr.openInputStream(src);
            out = cr.openOutputStream(dest, "wt");
            if (in == null || out == null) {
                return;
            }
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            out.flush();
        } catch (Exception e) {
            // kopia pomocnicza: brak błędu dla użytkownika
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e) {
                // ignoruj
            }
            try {
                if (out != null) {
                    out.close();
                }
            } catch (Exception e) {
                // ignoruj
            }
        }
    }

    private void writeBytes(ContentResolver cr, Uri uri, byte[] bytes, boolean append) throws Exception {
        OutputStream os = cr.openOutputStream(uri, append ? "wa" : "wt");
        if (os == null) {
            throw new Exception("OPEN_FAILED");
        }
        try {
            os.write(bytes);
            os.flush();
        } finally {
            os.close();
        }
    }

    @PluginMethod
    public void save(PluginCall call) {
        String name = call.getString("name");
        String data = call.getString("data");
        String folder = call.getString("folder", "SzczytFormy");
        String mime = call.getString("mime", "application/octet-stream");
        Boolean appendObj = call.getBoolean("append", false);
        boolean append = appendObj != null && appendObj.booleanValue();
        Integer totalObj = call.getInt("total", 0);
        long total = totalObj == null ? 0L : totalObj.longValue();

        if (name == null || data == null) {
            call.reject("BAD_ARGS");
            return;
        }
        if (Build.VERSION.SDK_INT < 29) {
            call.reject("UNSUPPORTED");
            return;
        }
        name = name.replace("/", "_").replace("\\", "_");
        folder = folder.replace("/", "_").replace("\\", "_");

        try {
            ContentResolver cr = getContext().getContentResolver();
            String rel = "Documents/" + folder + "/";
            byte[] bytes = Base64.decode(data, Base64.NO_WRAP);
            long id = findId(cr, name, rel);
            Uri uri = null;
            if (id >= 0) {
                uri = ContentUris.withAppendedId(collection(), id);
            }

            if (append) {
                if (uri == null) {
                    call.reject("NO_FILE");
                    return;
                }
                writeBytes(cr, uri, bytes, true);
            } else {
                if (uri != null) {
                    long oldSize = sizeOf(cr, id);
                    if (oldSize > 0) {
                        copyFile(cr, uri, name + ".bak", folder, "application/octet-stream");
                        if (oldSize > 20000 && total > 0 && total < oldSize / 3) {
                            copyFile(cr, uri, "przed-nadpisaniem_" + name, folder, mime);
                        }
                    }
                }
                boolean written = false;
                if (uri != null) {
                    try {
                        writeBytes(cr, uri, bytes, false);
                        written = true;
                    } catch (Exception first) {
                        // plik istnieje, ale nie da się go otworzyć do zapisu: usuń wpis i utwórz od nowa
                        try {
                            cr.delete(uri, null, null);
                        } catch (Exception ignore) {
                            // ignoruj
                        }
                        uri = null;
                    }
                }
                if (!written) {
                    uri = insertNew(cr, name, folder, mime);
                    if (uri == null) {
                        call.reject("INSERT_FAILED");
                        return;
                    }
                    writeBytes(cr, uri, bytes, false);
                }
            }

            JSObject r = new JSObject();
            r.put("uri", uri.toString());
            r.put("written", bytes.length);
            call.resolve(r);
        } catch (Exception e) {
            call.reject("SAVE_FAILED: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
}
