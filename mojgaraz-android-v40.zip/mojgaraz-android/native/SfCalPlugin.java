package pl.mojgaraz.app;

import android.Manifest;
import android.content.ContentProviderOperation;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import android.provider.CalendarContract.Calendars;
import android.provider.CalendarContract.Events;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

/**
 * Kalendarz „MójGaraż” w telefonie (lokalny, bez logowania). Widać go w aplikacji Kalendarz Google na tym telefonie.
 * Każda synchronizacja zastępuje wszystkie wydarzenia tego kalendarza aktualną listą z aplikacji (aplikacja jest źródłem prawdy).
 */
@CapacitorPlugin(
        name = "SfCal",
        permissions = {
                @Permission(alias = "calendar", strings = {Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR})
        }
)
public class SfCalPlugin extends Plugin {

    private static final String ACC_NAME = "MojGaraz";
    private static final String DISPLAY = "MójGaraż";

    private boolean granted() {
        return getPermissionState("calendar") == PermissionState.GRANTED;
    }

    private Uri asSync(Uri u) {
        return u.buildUpon()
                .appendQueryParameter(CalendarContract.CALLER_IS_SYNCADAPTER, "true")
                .appendQueryParameter(Calendars.ACCOUNT_NAME, ACC_NAME)
                .appendQueryParameter(Calendars.ACCOUNT_TYPE, CalendarContract.ACCOUNT_TYPE_LOCAL)
                .build();
    }

    private long findCalendar(ContentResolver cr) {
        Cursor c = null;
        try {
            c = cr.query(Calendars.CONTENT_URI, new String[]{Calendars._ID},
                    Calendars.ACCOUNT_NAME + "=? AND " + Calendars.ACCOUNT_TYPE + "=?",
                    new String[]{ACC_NAME, CalendarContract.ACCOUNT_TYPE_LOCAL}, null);
            if (c != null && c.moveToFirst()) {
                return c.getLong(0);
            }
        } catch (Exception e) {
            // brak wyniku
        } finally {
            if (c != null) {
                c.close();
            }
        }
        return -1L;
    }

    private long ensureCalendar(ContentResolver cr) {
        long id = findCalendar(cr);
        if (id >= 0) {
            return id;
        }
        ContentValues v = new ContentValues();
        v.put(Calendars.ACCOUNT_NAME, ACC_NAME);
        v.put(Calendars.ACCOUNT_TYPE, CalendarContract.ACCOUNT_TYPE_LOCAL);
        v.put(Calendars.NAME, "mojgaraz");
        v.put(Calendars.CALENDAR_DISPLAY_NAME, DISPLAY);
        v.put(Calendars.CALENDAR_COLOR, 0xFF1F6FEB);
        v.put(Calendars.CALENDAR_ACCESS_LEVEL, Calendars.CAL_ACCESS_OWNER);
        v.put(Calendars.OWNER_ACCOUNT, ACC_NAME);
        v.put(Calendars.VISIBLE, 1);
        v.put(Calendars.SYNC_EVENTS, 1);
        v.put(Calendars.CALENDAR_TIME_ZONE, TimeZone.getDefault().getID());
        Uri res = cr.insert(asSync(Calendars.CONTENT_URI), v);
        if (res == null) {
            return -1L;
        }
        return findCalendar(cr);
    }

    private long countEvents(ContentResolver cr, long calId) {
        Cursor c = null;
        try {
            c = cr.query(Events.CONTENT_URI, new String[]{Events._ID}, Events.CALENDAR_ID + "=?",
                    new String[]{String.valueOf(calId)}, null);
            return c == null ? 0L : (long) c.getCount();
        } catch (Exception e) {
            return 0L;
        } finally {
            if (c != null) {
                c.close();
            }
        }
    }

    /** „RRRR-MM-DD” → północ UTC w milisekundach (wydarzenia całodniowe liczy się w UTC). */
    private long dayUtc(String s) {
        String[] p = s.split("-");
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        cal.clear();
        cal.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, Integer.parseInt(p[2]), 0, 0, 0);
        return cal.getTimeInMillis();
    }

    @PluginMethod
    public void status(PluginCall call) {
        JSObject r = new JSObject();
        boolean ok = granted();
        r.put("granted", ok);
        boolean exists = false;
        long count = 0;
        if (ok) {
            try {
                ContentResolver cr = getContext().getContentResolver();
                long id = findCalendar(cr);
                exists = id >= 0;
                if (exists) {
                    count = countEvents(cr, id);
                }
            } catch (Exception e) {
                // ignoruj
            }
        }
        r.put("exists", exists);
        r.put("count", count);
        call.resolve(r);
    }

    @PluginMethod
    public void sync(PluginCall call) {
        if (!granted()) {
            requestPermissionForAlias("calendar", call, "syncPerm");
            return;
        }
        doSync(call);
    }

    @PermissionCallback
    private void syncPerm(PluginCall call) {
        if (granted()) {
            doSync(call);
        } else {
            call.reject("DENIED");
        }
    }

    private void doSync(PluginCall call) {
        try {
            JSArray arr = call.getArray("events");
            ContentResolver cr = getContext().getContentResolver();
            long calId = ensureCalendar(cr);
            if (calId < 0) {
                call.reject("NO_CALENDAR");
                return;
            }
            cr.delete(asSync(Events.CONTENT_URI), Events.CALENDAR_ID + "=?", new String[]{String.valueOf(calId)});
            int n = 0;
            ArrayList<ContentProviderOperation> ops = new ArrayList<ContentProviderOperation>();
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject e = arr.getJSONObject(i);
                    String date = e.optString("date", "");
                    String title = e.optString("title", "");
                    if (date.length() != 10 || title.length() == 0) {
                        continue;
                    }
                    long start;
                    try {
                        start = dayUtc(date);
                    } catch (Exception bad) {
                        continue;
                    }
                    ops.add(ContentProviderOperation.newInsert(asSync(Events.CONTENT_URI))
                            .withValue(Events.CALENDAR_ID, calId)
                            .withValue(Events.TITLE, title)
                            .withValue(Events.DESCRIPTION, e.optString("desc", ""))
                            .withValue(Events.DTSTART, start)
                            .withValue(Events.DTEND, start + 86400000L)
                            .withValue(Events.ALL_DAY, 1)
                            .withValue(Events.EVENT_TIMEZONE, "UTC")
                            .build());
                    n++;
                    if (ops.size() >= 100) {
                        cr.applyBatch(CalendarContract.AUTHORITY, ops);
                        ops.clear();
                    }
                }
            }
            if (!ops.isEmpty()) {
                cr.applyBatch(CalendarContract.AUTHORITY, ops);
            }
            JSObject r = new JSObject();
            r.put("count", n);
            call.resolve(r);
        } catch (Exception ex) {
            call.reject("SYNC_FAILED: " + ex.getMessage());
        }
    }

    @PluginMethod
    public void remove(PluginCall call) {
        if (!granted()) {
            call.resolve();
            return;
        }
        try {
            ContentResolver cr = getContext().getContentResolver();
            long id = findCalendar(cr);
            if (id >= 0) {
                cr.delete(asSync(Calendars.CONTENT_URI), Calendars._ID + "=?", new String[]{String.valueOf(id)});
            }
            call.resolve();
        } catch (Exception ex) {
            call.reject("REMOVE_FAILED: " + ex.getMessage());
        }
    }
}
